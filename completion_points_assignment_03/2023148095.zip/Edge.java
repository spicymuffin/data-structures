public class Edge {
    int v1;
    int v2;
    int w;

    public Edge(int _v1, int _v2, int _w) {
        w = _w;
        v1 = _v1;
        v2 = _v2;
    }
}
