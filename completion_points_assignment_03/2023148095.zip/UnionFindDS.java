public class UnionFindDS {
    int[] p;
    int[] c;
    int sz;

    public UnionFindDS(int s) {
        p = new int[s];
        c = new int[s];
        sz = s;

        for (int i = 0; i < sz; i++) {
            p[i] = -1;
            c[i] = 1;
        }
    }

    public int findSetName(int nd) {
        while (p[nd] != -1) {
            nd = p[nd];
        }
        return nd;
    }

    public int uniteSets(int set0, int set1) {
        if (c[set0] >= c[set1]) {
            p[set1] = set0;
            c[set0] += c[set1];
            return set0;
        } else {
            p[set0] = set1;
            c[set1] += c[set0];
            return set1;
        }
    }
}