import java.io.FileReader;
import java.io.BufferedReader;
import java.io.FileWriter;
import java.io.BufferedWriter;

public class CPA3 {

    public static void sortEdgeArrayNonDescending(Edge[] arr, int left, int right) {
        if (left >= right) {
            return;
        }

        int j = left;
        Edge tmp;
        for (int i = left + 1; i <= right; i++) {
            if (arr[i].w < arr[left].w) {
                j++;
                tmp = arr[j];
                arr[j] = arr[i];
                arr[i] = tmp;
            }
        }
        tmp = arr[left];
        arr[left] = arr[j];
        arr[j] = tmp;
        sortEdgeArrayNonDescending(arr, left, j - 1);
        sortEdgeArrayNonDescending(arr, j + 1, right);
    }

    public static void main(String[] args) {
        Edge[] edgeArray = new Edge[0];
        int vertexCount = 0;
        int edgeCount = 0;
        String[] result;
        try {
            BufferedReader rd = new BufferedReader(new FileReader("input.txt"));
            String[] input;

            input = rd.readLine().split(" ");
            vertexCount = Integer.parseInt(input[0]);
            edgeCount = Integer.parseInt(input[1]);

            result = new String[vertexCount - 1];
            edgeArray = new Edge[edgeCount];
            UnionFindDS uf = new UnionFindDS(vertexCount);

            int spanningTreeCurrentEdgeCount = 0;
            int set1Name, set2Name;

            for (int i = 0; i < edgeCount; i++) {
                input = rd.readLine().split(" ");
                edgeArray[i] = new Edge(Integer.parseInt(input[0]), Integer.parseInt(input[1]),
                        Integer.parseInt(input[2]));
            }

            sortEdgeArrayNonDescending(edgeArray, 0, edgeCount - 1);

            for (int i = 0; i < edgeCount; i++) {
                if ((set1Name = uf.findSetName(edgeArray[i].v1)) != (set2Name = uf.findSetName(edgeArray[i].v2))) {
                    uf.uniteSets(set1Name, set2Name);
                    result[spanningTreeCurrentEdgeCount] = edgeArray[i].v1 + " " + edgeArray[i].v2 + "\n";
                    spanningTreeCurrentEdgeCount++;
                    if (spanningTreeCurrentEdgeCount == vertexCount - 1) {
                        break;
                    }
                }
            }

            BufferedWriter wr = new BufferedWriter(new FileWriter("output.txt"));

            if (spanningTreeCurrentEdgeCount == (vertexCount - 1)) {
                for (int i = 0; i < spanningTreeCurrentEdgeCount; i++) {
                    wr.write(result[i]);
                }
            } else {
                wr.write("none");
            }

            wr.close();
        } catch (Exception exception) {
            System.out.println("error");
        }
    }
}
