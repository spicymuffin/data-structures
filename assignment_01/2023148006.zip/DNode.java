public class DNode {
    public int data;
    public DNode prev, next;

    // custom
    public DNode(int _data) {
        data = _data;
    }

    public DNode() {

    }
}