public class Node {
    public Node next;
    public int value;

    public Node(Node _next, int _value) {
        next = _next;
        value = _value;
    }
}